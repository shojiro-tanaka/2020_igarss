#作業ディレクトリをこのファイルと同じ場所に変更
#setwd(dirname(sys.frame(1)$ofile))
#Use COPY & PASTE. Do not drop this file.
#全変数の初期化，リセット
rm(list=ls(all=TRUE))
dev.off()

sink(file = "twoStageEstimation.log")  # 出力をログファイルに書き込む

load("../01_vectorsFormulation/outputVectorsAndParam.rdata")
dim(vectors)
s <- 3
t <- 2
# [1:logitF, 2:intercept, 3:g, 4:h, 5:u, 6:v]
y = vectors[,1]
g = vectors[,3]
h = vectors[,4]
u = vectors[,5]
v = vectors[,6]
#################################################################################
# Population effect was reversed. 
# See line 63 in "./pmlVerification/01_vectorsFormulation/vectorsByBestModel.r"
g = -g
#################################################################################
gh = g+h
uv = u+v

n = length(y)

lm00 = lm(y-g-h ~ 1)            ; summary(lm00)
lm01 = lm(y-g-h ~         uv   ); summary(lm01)
lm02 = lm(y-g-h ~         u + v); summary(lm02)
lm11 = lm(y     ~ gh    + uv   ); summary(lm11)
lm12 = lm(y     ~ gh    + u + v); summary(lm12)
lm21 = lm(y     ~ g + h + uv   ); summary(lm21)
lm22 = lm(y     ~ g + h + u + v); summary(lm22)

hist(lm00$residuals)
dev.new()
boxplot(lm00$residuals, lm01$residuals,lm02$residuals,lm11$residuals,lm12$residuals,lm21$residuals,lm22$residuals)
                                     # 正しい g = -g       ## 間違っている g
(mse00 = sum((lm00$residuals)^2)/n)  # mse00 = 1.465158    ## mse00 = 5.20298
(mse01 = sum((lm01$residuals)^2)/n)  # mse01 = 1.461259    ## mse01 = 5.072878
(mse02 = sum((lm02$residuals)^2)/n)  # mse02 = 1.450494    ## mse02 = 4.567478
(mse11 = sum((lm11$residuals)^2)/n)  # mse11 = 1.461254    ## mse11 = 3.447058
(mse12 = sum((lm12$residuals)^2)/n)  # mse12 = 1.447733    ## mse12 = 2.907701
(mse21 = sum((lm21$residuals)^2)/n)  # mse21 = 1.461025    ## mse21 = 1.461025
(mse22 = sum((lm22$residuals)^2)/n)  # mse22 = 1.447732    ## mse22 = 1.447732
                                                         
(aic00 = n*log(mse00) + 2*7)         # aic00 = 2597.982    ## aic00 = 11171.05
(aic01 = n*log(mse01) + 2*8)         # aic01 = 2581.955    ## aic01 = 11001.74
(aic02 = n*log(mse02) + 2*8)         # aic02 = 2531.93 *   ## aic02 = 10291.77
(aic11 = n*log(mse11) + 2*9)         # aic11 = 2583.931    ## aic11 =  8389.83
(aic12 = n*log(mse12) + 2*10)        # aic12 = 2523.042*** ## aic12 =  7240.70
(aic21 = n*log(mse21) + 2*10)        # aic21 = 2584.872    ## aic21 =  2584.872
(aic22 = n*log(mse22) + 2*11)        # aic22 = 2525.039**  ## aic22 =  2525.039
                                                         
(bic00 = n*log(mse00) + log(n)*7)    # bic00 = 2645.718    ## bic00 = 11218.79
(bic01 = n*log(mse01) + log(n)*8)    # bic01 = 2636.511    ## bic01 = 11056.3
(bic02 = n*log(mse02) + log(n)*8)    # bic02 = 2586.487*** ## bic02 = 10346.33
(bic11 = n*log(mse11) + log(n)*9)    # bic11 = 2645.307    ## bic11 =  8451.206
(bic12 = n*log(mse12) + log(n)*10)   # bic12 = 2591.238**  ## bic12 =  7308.904
(bic21 = n*log(mse21) + log(n)*10)   # bic21 = 2653.067    ## bic21 =  2653.067
(bic22 = n*log(mse22) + log(n)*11)   # bic22 = 2600.054*   ## bic22 =  2600.054

sink()  # (引数無し) 出力を再びコンソールに切替え 
#dev.off()
closeAllConnections()

