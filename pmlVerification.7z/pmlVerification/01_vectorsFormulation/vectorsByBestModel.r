#��ƃf�B���N�g�������̃t�@�C���Ɠ����ꏊ�ɕύX
setwd(dirname(sys.frame(1)$ofile))

#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

#dir.create("./logPml")
#sink('./logPml/vectorsFormulation.txt')

tmp <- list.files("./")
str<-paste(".", tmp[1], sep = "/")

resultG2H2 <- readRDS(str)

#library("Matrix")
#library(MASS)

# N:�l�����x
# R:�W����
# H1:�אڍs��

# �����ϐ��̓ǂݍ���
X = read.csv("../../00_dataToRead/X.csv", header=FALSE)
#colnames(X)[4:6] = c("F", "N", "R")

F = data.matrix(X[, 4])
N = data.matrix(X[, 5])
R = data.matrix(X[, 6])
#altmean = data.matrix(X[, 7])

logitF <- log ( F/(1.0 - F) )
logN <- log( N+1.0 )
adjustTerm <- 2*sum(log(F*(1.0-F)))
rm(X, F, N)

dataSize = nrow(logitF)

print(dataSize)
print(resultG2H2)

#�P���אڍs��̓ǂݍ���
H1_mat = read.csv("../../00_dataToRead/H1_mat.csv", header=FALSE)
H1 = data.matrix(H1_mat)
sum(rowSums(H1)-colSums(H1))
rm(H1_mat)

# G2H2 ##############################################################
 B1 = resultG2H2$par[2] * ( 1 / (1 + exp(resultG2H2$par[3] - resultG2H2$par[4] * logN) )
                 - (1 / (1 + exp(resultG2H2$par[3]))))
 B2 <- matrix( 0, nrow = dataSize, ncol =1 )
 for( i in 1:dataSize ){
   if (R[i] <= resultG2H2$par[5]) B2[i] <- 0 
   else B2[i] <- resultG2H2$par[6] * log( R[i] / resultG2H2$par[5] )
 }


 #B2 = resultG2H2$par[6] * log(R / resultG2H2$par[5]) * (sign(R - resultG2H2$par[5]) + 1) / 2
 ## R=0�̂Ƃ��̗�O����
 #B2[is.nan(B2)] = 0
 #B2[is.infinite(B2)] = 0
 #B2 = B2 + resultG2H2$par[7]*altmean

 estLogitF <- resultG2H2$par[1] - B1 + B2 # + resultG2H2$par[7]*altmean



# 20191223 vectors output for verification ##########################
#####################################################################

rowSummed1  = matrix(rowSums(H1))

gN1sum = H1 %*% B1
gN1ave = gN1sum/rowSummed1
gN1ave[is.nan(gN1ave)] = B1[is.nan(gN1ave)]
#checkgN1ave <- cbind(B1, gN1ave, rowSummed1)

hR1sum = H1 %*% B2
hR1ave = hR1sum/rowSummed1
hR1ave[is.nan(hR1ave)] = B2[is.nan(hR1ave)]
#checkhR1ave <- cbind(B2, hR1ave, rowSummed1)

vectors <- cbind(logitF, resultG2H2$par[1], B1, B2, gN1ave, hR1ave)
save(vectors,logitF, logN, R, estLogitF, adjustTerm, file="outputVectorsAndParam.Rdata")

####################################################################


