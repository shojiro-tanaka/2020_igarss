Raw data and previous programs are available at
https://github.com/shojiro-tanaka/2019_igarss_1919-1922 .