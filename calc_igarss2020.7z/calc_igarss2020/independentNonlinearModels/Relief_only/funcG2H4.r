LL <- function(beta){
 count <<- count + 1
 char = paste0('[', count, '] ')
 space = paste0(rep(" ", length=nchar(char)), collapse="")
 cat(paste0(char, 'beta = (', paste(beta,collapse=", "), ')\n'))

 for(k in 2:length(beta)){
  if(beta[k] < 0) beta[k] = 1e-6 * abs(rnorm(1))
 }

 B1 = beta[2] * ( 1 / (1 + exp(beta[3] - beta[4] * logN) )
                 - (1 / (1 + exp(beta[3]))))
 B2 = beta[5] * ( 1.0 / (1.0+exp(beta[6]-beta[7] * R)) - 1.0 / (1.0 + exp(beta[6])) )
 #
 B = beta[1] - B1 + B2

residual <- data.matrix(logitF - B)
mse = (t(residual) %*% residual) / dataSize

logMse <- log(mse)
final <- as.numeric( dataSize*logMse )
AIC <- final +adjustTerm + 2*(length(beta)+1)
BIC <- final +adjustTerm + log(dataSize)*(length(beta)+1)
cat(paste0(space, 'mse = ', sprintf("%3.5f", mse), '\n', space, 'AIC = ', sprintf("%3.5f", AIC), '\n', space, 'BIC = ', sprintf("%3.5f", BIC), '\n'))
return( BIC )
}
