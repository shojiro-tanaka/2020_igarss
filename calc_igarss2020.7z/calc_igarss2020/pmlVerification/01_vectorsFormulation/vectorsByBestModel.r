#��ƃf�B���N�g�������̃t�@�C���Ɠ����ꏊ�ɕύX
#setwd(dirname(sys.frame(1)$ofile))

#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

#dir.create("./logPml")
#sink('./logPml/vectorsFormulation.txt')

tmp <- list.files("./")
str<-paste(".", tmp[1], sep = "/")

resultG2H2 <- readRDS(str)

#library("Matrix")
#library(MASS)

# N:�l�����x
# R:�W����
# H1:�אڍs��

# �����ϐ��̓ǂݍ���
X = read.csv("../../00_dataToRead/X.csv", header=FALSE)
#colnames(X)[4:6] = c("F", "N", "R")

F = data.matrix(X[, 4])
N = data.matrix(X[, 5])
R = data.matrix(X[, 6])
#altmean = data.matrix(X[, 7])

logitF <- log ( F/(1.0 - F) )
logN <- log( N+1.0 )
adjustTerm <- 2*sum(log(F*(1.0-F)))
rm(X, F, N)

dataSize = nrow(logitF)

print(dataSize)
print(resultG2H2)

#�P���אڍs��̓ǂݍ���
H1_mat = read.csv("../00_dataToRead/H1_mat.csv", header=FALSE)
H1 = data.matrix(H1_mat)
sum(rowSums(H1)-colSums(H1))
rm(H1_mat)

# G2H2 ##############################################################
 B1 = resultG2H2$par[2] * ( 1 / (1 + exp(resultG2H2$par[3] - resultG2H2$par[4] * logN) )
                 - (1 / (1 + exp(resultG2H2$par[3]))))
 B2 <- matrix( 0, nrow = dataSize, ncol =1 )
 for( i in 1:dataSize ){
   if (R[i] <= resultG2H2$par[5]) B2[i] <- 0 
   else B2[i] <- resultG2H2$par[6] * log( R[i] / resultG2H2$par[5] )
 }


 #B2 = resultG2H2$par[6] * log(R / resultG2H2$par[5]) * (sign(R - resultG2H2$par[5]) + 1) / 2
 ## R=0�̂Ƃ��̗�O����
 #B2[is.nan(B2)] = 0
 #B2[is.infinite(B2)] = 0
 #B2 = B2 + resultG2H2$par[7]*altmean

 estLogitF <- resultG2H2$par[1] - B1 + B2 # + resultG2H2$par[7]*altmean



# 20191223 vectors output for verification ##########################
#####################################################################

rowSummed1  = matrix(rowSums(H1))

gN1sum = H1 %*% B1
gN1ave = gN1sum/rowSummed1
gN1ave[is.nan(gN1ave)] = B1[is.nan(gN1ave)]
#checkgN1ave <- cbind(B1, gN1ave, rowSummed1)

hR1sum = H1 %*% B2
hR1ave = hR1sum/rowSummed1
hR1ave[is.nan(hR1ave)] = B2[is.nan(hR1ave)]
#checkhR1ave <- cbind(B2, hR1ave, rowSummed1)

outputVectors2 <- cbind(logitF, resultG2H2$par[1], B1, B2, gN1ave, hR1ave)
saveRDS(outputVectors2, file="outputVectors2.rdata")

####################################################################



















####################################################################
### independent model
### NOTE: mse0 is for the estimate of y = xBeta0 y_hat + error
XX0    = estLogitF;
residual0 <- logitF - estLogitF
XX0sq  = t(XX0) %*% XX0;
xBeta0 = solve(XX0sq) * t(XX0) %*% logitF
mse0   = ( (t(logitF) %*% logitF) - t(xBeta0) * (XX0sq) * xBeta0 )/dataSize
mse0b  = (t(residual0) %*% residual0)/dataSize
aic0   = dataSize*log(mse0) + adjustTerm + 2*( 1 + length(data.matrix(resultG2H2$par)) )
bic0   = dataSize*log(mse0) + adjustTerm + log(dataSize)*( 1 + length(data.matrix(resultG2H2$par)) )
bic0b  = dataSize*log(mse0b) + adjustTerm + log(dataSize)*( 1 + length(data.matrix(resultG2H2$par)) )
cat("beta0  = ", paste(xBeta0),"\n")
cat(" mse0  = ", paste(mse0),",")
cat(" mse0b = ", paste(mse0b),",")
cat(" aic0  = ", paste(aic0),",")
cat(" bic0  = ", paste(bic0),"\n\n")
cat(" bic0b = ", paste(bic0b),"\n\n")

### 1st-order neighbors
rowSummed1  = matrix(rowSums(H1))
xEstLF1sum  = H1 %*% estLogitF
xEstLF1ave  = xEstLF1sum/rowSummed1;
xEstLF1ave[is.nan(xEstLF1ave)] = estLogitF[is.nan(xEstLF1ave)]

XX1    = cbind(estLogitF, xEstLF1ave);
XX1sq  = t(XX1) %*% XX1;
xBeta1 = solve(XX1sq) %*% t(XX1) %*% logitF
mse1   = (t(logitF) %*% logitF - t(xBeta1) %*% XX1sq %*% xBeta1)/dataSize
aic1   = dataSize*log(mse1) + adjustTerm + 2*(1 +length(xBeta1))
bic1   = dataSize*log(mse1) + adjustTerm + log(dataSize)*(1 +length(xBeta1))
cat("beta1  = ", paste(xBeta1),"\n")
cat(" mse1  = ", paste(mse1),",")
cat(" aic1  = ", paste(aic1),",")
cat(" bic1  = ", paste(bic1),"\n\n")


sink()
closeAllConnections()
