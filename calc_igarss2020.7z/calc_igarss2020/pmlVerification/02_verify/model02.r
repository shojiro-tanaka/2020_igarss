#��ƃf�B���N�g�������̃t�@�C���Ɠ����ꏊ�ɕύX
#setwd(dirname(sys.frame(1)$ofile))

#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

vectors <- readRDS("../01_vectorsFormulation/outputVectors2.rdata")
dim(vectors)
s <- 3
t <- 2
# [1:logitF, 2:intercept, 3:g, 4:h, 5:u, 6:v]

targetVar <- as.matrix(vectors[,1] - vectors[,3] - vectors[,4])
dim(targetVar)


#explanatoryVar <- as.matrix(vectors[,5]+vectors[,6])
#dim(explanatoryVar)

sink("M02.log")
lm1   = lm(targetVar ~ vectors[,5]+vectors[,6])
p     = s + t + 4
mse   = sum(lm1$residuals^2)/length(targetVar)
mse2  = sum(lm1$residuals^2)/(length(targetVar)-p+1)
logL  = - length(targetVar) * (log(2*pi*exp(1)) + log(mse ))/2
logL2 = - length(targetVar) * (log(2*pi*exp(1)) + log(mse2))/2
AIC   = -2*logL + 2*p
BIC   = -2*logL + log(length(targetVar))*p
summary(lm1)
cat("\n mse =", mse, "logL =", logL, "mse2 =", mse2, "logL2 =", logL2, "p =", p, "AIC =", AIC, "BIC =", BIC, "\n")
sink()
